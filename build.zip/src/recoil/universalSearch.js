import { atom } from 'recoil'

export const universalSearchState = atom({
	key: "universalSearchState",
	default: ""
})