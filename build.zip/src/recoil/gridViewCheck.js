import { atom } from 'recoil'

export const gridViewMemberState = atom({
    key:"viewCheck",
    default:"true"
})

export const gridViewProjectState = atom({
    key:"viewCheck",
    default:"true"
})

export const gridViewClientState = atom({
    key:"viewCheck",
    default:"true"
})

export const gridViewDirectoryState = atom({
    key:"viewCheck",
    default:"true"
})