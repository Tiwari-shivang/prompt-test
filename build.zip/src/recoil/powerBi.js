import { atom } from "recoil";

export const powerBiPagesState = atom({
  key: "powerBiPagesState",
  default: [],
});