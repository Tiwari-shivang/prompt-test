import http from '../../../utilits/httpClient'

export const deleteLocation = async (id) => {
    try {
        const { data } = await http().delete(`organisation/locations/delete/${id}`)
        return data
    } catch (error) {
        throw Error(error.response.data.message)
    }
}
