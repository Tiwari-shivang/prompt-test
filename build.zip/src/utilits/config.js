const config = {
    BASE_API_URL: "https://api-korporate-dev.hexaviewtech.com:8120",
   
    TIMEOUT: 300000, // 5 minutes = 60x5x1000 = 300000
}
export default config;